

npm login

Tocken from github:

GH_PASS=`cat ~/.ghtoken`

Password from WP:
WP_PASSWORD=`cat ~/.wppassword`