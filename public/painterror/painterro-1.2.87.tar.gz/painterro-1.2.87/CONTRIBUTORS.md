

Painterro contributors
============================================

* **[Jesfery](https://github.com/Jesfery)**

  * defaultTool param
  
* **[Ivan Borshchov](https://github.com/ivictbor)**  
  * maintainer