---
name: Feature request
about: Create a feature which makes Painterro better
title: ''
labels: ''
assignees: ''

---

**Describe the feature**
A clear and concise description of what you want to see and how it should work. Step by step, then we will adjust if needed

**Possible analogs?**
Gimp, MSPaint, Inkscape, etc...
